using System;

namespace _02.Bank_accounts
{
    public class Company : Customer
    {
        public Company(string name)
            : base(name)
        {
            
        }
    }
}