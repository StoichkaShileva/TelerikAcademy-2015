namespace _02.Bank_accounts
{
    public class Individual : Customer
    {
        public Individual(string name)
            : base(name)
        {
            
        }
    }
}