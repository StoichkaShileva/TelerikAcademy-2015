﻿using System.Collections.Generic;

namespace Problem_1.School_classes
{
    public interface IDiscipline
    {
        List<Discipline> Disciplines { get; set; }
    }
}
