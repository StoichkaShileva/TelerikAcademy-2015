﻿namespace Problem_1.Student_class
{
    public enum University
    {
        Softuni,
        New_Bulgarian_University,
        Cambridge,
        Sofia_University,
        Technical_University
    }
}
