﻿namespace Problem_1.Student_class
{
    public enum Faculty
    {
        Electrical,
        Math_Informatics,
        Transport
    }
}
