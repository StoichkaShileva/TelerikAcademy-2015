﻿namespace Problem_1.Student_class
{
    public enum Specialty
    {
		Economy,
		Programming,
		Banking,
		Internet_Security,
		Math
    }
}
