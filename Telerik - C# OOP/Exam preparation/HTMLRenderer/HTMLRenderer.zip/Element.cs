﻿using System;
using System.Linq;

namespace HTMLRenderer
{
    using System.Collections.Generic;
    using System.Text;
    public class Element : IElement
    {
        private string name;
        private string textContent;
        private List<IElement> childElements;

        public Element()
        {
            childElements = new List<IElement>();
        }
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public string TextContent
        {
            get { return this.textContent; }
            set { this.textContent = value; }
        }

        public IEnumerable<IElement> ChildElements
        {
            get { return new List<IElement>(this.childElements); }
        }

        public void AddElement(IElement element)
        {
            this.childElements.Add(element);
        }

        public override string ToString()
        {
            return string.Format("{0}{1}{2}{3}", this.Name == null ? "" : "<" + this.Name.ToString() + ">", this.textContent, this.childElements.Count > 0 ? PrintChilds() : "", this.Name == null ? "" : "</" + this.Name.ToString() + ">");
        }

        private string PrintChilds()
        {
            string st = String.Empty;
            foreach (var childElement in childElements)
            {
                st += childElement.ToString();
            }
            return st;
        }
        private string FormatTextContent(string text)
        {
            string formatted = string.Empty;
            if (text == null)
                text = string.Empty;
            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] == '<')
                {
                    formatted += "&lt;";
                }
                else if (text[i] == '>')
                {
                    formatted += "&gt;";
                }
                else if (text[i] == '&')
                {
                    formatted += "&amp;";
                }
                else
                {
                    formatted += text[i];
                }
            }
            return formatted;
        }
        public void Render(StringBuilder output)
        {
            Console.WriteLine(output);
        }
    }
}
