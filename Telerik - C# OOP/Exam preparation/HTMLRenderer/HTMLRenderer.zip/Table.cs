﻿using System.Collections.Generic;

namespace HTMLRenderer
{
    using System;
    public class Table : Element, ITable
    {
        private IElement[,] table;
        private int rows;
        private int cols;

        public Table(int inputRows, int inputCols)
        {
            this.table = new IElement[inputRows, inputCols];
        }
        public int Rows
        {
            get { return this.rows; }
        }

        public int Cols
        {
            get { return this.cols; }
        }

        public IElement this[int row, int col]
        {
            get { return this.table[row, col]; }
            set { this.table[row, col] = value; }
        }

        public override string ToString()
        {
            return
                string.Format(
                    "<table>" +  PrintTable() + "</table>");
        }

        
        private string PrintTable()
        {
            string str = string.Empty;
            for (int row = 0; row < table.GetLength(0); row++)
            {
                str += "<tr>";
                for (int col = 0; col < table.GetLength(1); col++)
                {
                    str += "<td>";
                    str += table[row,col];//FormatTextContent(table[row, col]);
                    str += "</td>";
                }
                str += "</tr>";
            }
            return str;
        }
    }
}
