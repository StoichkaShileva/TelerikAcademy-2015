﻿namespace FurnitureManufacturer.Models
{
    using FurnitureManufacturer.Interfaces;
    class Table : Furniture, ITable
    {
        private decimal length;
        private decimal width;
        public decimal Length
        {
            get { return this.length; }
            set { this.length = value; }
        }

        public decimal Width
        {
            get { return this.width; }
            set { this.width = value; }
        }

        public decimal Area
        {
            get { return this.Length*this.Height; }
        }
    }
}
