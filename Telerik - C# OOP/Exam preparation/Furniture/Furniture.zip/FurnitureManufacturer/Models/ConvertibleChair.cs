﻿using FurnitureManufacturer.Interfaces;

namespace FurnitureManufacturer.Models
{
    public class ConvertibleChair : Chair, IConvertibleChair
    {
        private bool isConverted = false;

        public ConvertibleChair()
        {
            this.IsConverted = false;
        }

        public bool IsConverted
        {
            get { return this.isConverted; }
            private set { this.isConverted = value; }
        }

        public void Convert()
        {
            if (this.IsConverted == false)
            {
                this.Height = 0.10m;
                this.IsConverted = true;
            }
            else
            {
                this.Height = Height;
                this.IsConverted = false;
            }
        }
    }
}
