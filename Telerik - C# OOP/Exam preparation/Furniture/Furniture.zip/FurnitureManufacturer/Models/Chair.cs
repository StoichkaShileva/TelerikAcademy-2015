﻿namespace FurnitureManufacturer.Models
{
    using FurnitureManufacturer.Interfaces;

    public class Chair : Furniture, IChair
    {
        private int numberOfLegs;
        public int NumberOfLegs
        {
            get { return this.numberOfLegs; }
            set { this.numberOfLegs = value; }
        }
    }
}
