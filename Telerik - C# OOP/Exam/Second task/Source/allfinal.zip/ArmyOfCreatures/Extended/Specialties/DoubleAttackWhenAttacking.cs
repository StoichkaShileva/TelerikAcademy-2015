﻿namespace ArmyOfCreatures.Extended.Specialties
{
    using System.Globalization;
    using System;

    using ArmyOfCreatures.Logic.Battles;
    using ArmyOfCreatures.Logic.Specialties;
    
    public class DoubleAttackWhenAttacking : Specialty
    {
        private const int MinimumRounds = 0;
        private const int AttackMultily = 2;
        private int rounds;

        public DoubleAttackWhenAttacking(int rounds)
        {
            if (rounds <= MinimumRounds)
            {
                throw new ArgumentOutOfRangeException("rounds", "The number of rounds should be greater than 0");
            }

            this.rounds = rounds;
        }
        //ICreaturesInBattle attackerWithSpecialty, ICreaturesInBattle defender
        public override void ApplyWhenAttacking(ICreaturesInBattle attackerWithSpecialty, ICreaturesInBattle defender)
        {
            if (attackerWithSpecialty == null)
            {
                throw new ArgumentNullException("attackerWithSpecialty");
            }

            if (defender == null)
            {
                throw new ArgumentNullException("defender");
            }

            if (this.rounds <= MinimumRounds)
            {
                // Effect expires after fixed number of rounds
                return;
            }

            attackerWithSpecialty.CurrentAttack *= AttackMultily;
            this.rounds--;
        }

        public override string ToString()
        {
            return string.Format(CultureInfo.InvariantCulture, "{0}({1})", base.ToString(), this.rounds);
        }
    }
}
