﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_7.Quotes_in_Strings
{
    class QuotesInStrings
    {
        static void Main(string[] args)
        {
            string value = "The \"use\" of quotations causes difficulties.";
            string valueTwo = "The use of quotations causes difficulties.";
            Console.WriteLine(value);
            Console.WriteLine(valueTwo);
        }
    }
}
