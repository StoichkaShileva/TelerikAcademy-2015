﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_5.Boolean_Variable
{
    class BooleanVariable
    {
        static void Main(string[] args)
        {
            bool isFemale = false;
            Console.WriteLine(isFemale);
        }
    }
}
