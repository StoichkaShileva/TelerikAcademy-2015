﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_1.Declare_Variables
{
    class DeclareVariables
    {
        static void Main(string[] args)
        {
            ushort firstValue = 52130;
            sbyte secondValue = -115;
            int thirdValue = 4825932;
            byte fourthValue = 97;
            short lastValue = -10000;
        }
    }
}
