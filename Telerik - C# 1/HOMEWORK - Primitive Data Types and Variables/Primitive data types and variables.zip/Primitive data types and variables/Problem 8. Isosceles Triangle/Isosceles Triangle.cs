﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_8.Isosceles_Triangle
{
    class IsoscelesTriangle
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            char c = '\u00a9';
            Console.WriteLine("   {0}", c);
            Console.WriteLine("  {0} {0}",c );
            Console.WriteLine(" {0}  {0}", c);
            Console.WriteLine("{0} {0} {0} {0}", c);
        }
    }
}
