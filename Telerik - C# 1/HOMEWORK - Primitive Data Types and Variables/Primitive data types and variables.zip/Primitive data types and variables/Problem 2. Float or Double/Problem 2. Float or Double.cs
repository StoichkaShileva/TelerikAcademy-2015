﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_2.Float_or_Double
{
    class FloatOrDouble
    {
        static void Main(string[] args)
        {
            double firstValue = 34.567839023;
            float secondValue = 12.345F;
            double thirdValue = 8923.1234857;
            float lastValue = 3456.019F;
            Console.WriteLine(secondValue);
        }
    }
}
