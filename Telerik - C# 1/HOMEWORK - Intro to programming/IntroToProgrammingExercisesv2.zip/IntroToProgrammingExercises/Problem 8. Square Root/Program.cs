﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_8.Square_Root
{
    class SquareRoot
    {
        static void Main(string[] args)
        {
            int num = 12345;
            Console.WriteLine(Math.Sqrt(num));
        }
    }
}
