﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_7.Print_First_and_Last_Name
{
    class FirstAndLastNamePrint
    {
        static void Main(string[] args)
        {
            string firstName = "Pesho";
            string lastName = "Peshov";
            Console.WriteLine("{0} {1}", firstName, lastName);
        }
    }
}
